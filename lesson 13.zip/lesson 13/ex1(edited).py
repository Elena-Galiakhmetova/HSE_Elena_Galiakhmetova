import requests
from bs4 import BeautifulSoup
import pandas as pd
from datetime import datetime

class ParserCBRF:
    def __init__(self, url):
        self.url = url
        self.data = {}

    def start(self):
        if self.url.endswith(('.xls', '.xlsx', '.pdf', '.csv')):
            self._download_file()
        else:
            self._parse_page()

    def _parse_page(self):
        response = requests.get(self.url)
        soup = BeautifulSoup(response.content, 'html.parser')
        table = soup.find('table', {'class': 'data'})

        if table:
            rows = table.find_all('tr')
            for row in rows:
                cells = row.find_all('td')
                if len(cells) == 2:
                    date_str = cells[0].text.strip()
                    value_str = cells[1].text.strip()
                    date = datetime.strptime(date_str, '%d.%m.%Y').date()
                    value = float(value_str.replace(',', '.'))
                    self.data[date] = value
        else:
            print('На данной странице не найдены таблицы')

    def _download_file(self):
        response = requests.get(self.url)
        file_name = self.url.split('/')[-1]
        with open(file_name, 'wb') as file:
            file.write(response.content)
            print(f"Файл {file_name} загружен в рабочую директорию")

        if file_name.endswith('.xls') or file_name.endswith('.xlsx'):
            self._parse_excel(file_name)
        elif file_name.endswith('.csv'):
            self._parse_csv(file_name)
        elif file_name.endswith('.pdf'):
            pass
        else:
            print('Расширение данного файла не поддерживается')

    def _parse_excel(self, file_name):
        df = pd.read_excel(file_name)
        for _, row in df.iterrows():
            date_str = row[0]
            value = (row[1])
            self.data[date_str] = value
        print("Данные сохранены в переменную data")

    def _parse_csv(self, file_name):
        df = pd.read_csv(file_name)
        for _, row in df.iterrows():
            date_str = row[0]
            value = row[1]
            self.data[date_str] = value
        print("Данные сохранены в переменную data")


parser = ParserCBRF("https://cbr.ru/vfs/statistics/credit_statistics/reserves_liquidity_23.xlsx")
parser.start()
print(parser.data)