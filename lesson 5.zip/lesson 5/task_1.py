# task 1

import json

output_file = open("traders.csv", "w")

with open("traders.txt", "r") as input_file_inn:
    inn_list = input_file_inn.readlines()
    inn_list = [el.strip("\n") for el in inn_list]

with open("traders.json", "r") as input_file_info:
    traders_info = json.load(input_file_info)

print("[RESULT]")
for el in traders_info:
    if el['inn'] in inn_list:
        line = "{0};{1};{2}".format(el['inn'], el['ogrn'], el['address'])
        print(line)
        output_file.write(line + "\n")

output_file.close()
