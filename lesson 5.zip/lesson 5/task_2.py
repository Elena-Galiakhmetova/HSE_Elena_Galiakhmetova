# task 2

import json
from re import findall

res_dict = {}

def find_emails(text):
    re_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b'
    res = set(findall(re_pattern, text))

    return res

with open("1000_efrsb_messages.json", "r") as input_file:
    input_text = ""
    input_data = json.load(input_file)
    for el in input_data:
        input_text += "".join(el['msg_text'])
        emails = find_emails(input_text)
        res_dict[el['publisher_inn']] = set(emails)

with open("emails.json", "w") as output_file:
    output_file.write(str(res_dict))

output_file.close()